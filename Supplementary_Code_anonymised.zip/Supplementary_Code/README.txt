Supplementary code: PVT night rejection + recycled-wash-water hybrid cooler model
=================================================================================

Requirements: Python 3.9 or later, NumPy, Matplotlib (figures only).
    pip install -r requirements.txt
All calculations are deterministic.

Run every command from inside this folder (Supplementary_Code/).

1. Quick check (about 30 s): reruns Phoenix, 130.5 kW module, and compares it
   with the published results.
       python reproduce_check.py

2. Full reproduction (about 9 min):
       python run_all.py            -> results/results.json   (all scenarios; tower and dry-cooler
                                                               comparisons; three host types;
                                                               sensitivities; PVT uncertainty)
       python make_rows.py          -> results/rows.json      (table rows and percentages)
       python make_figures.py       -> figures/Fig1-Fig8 .png
       python reproduce_check.py --full
   The last command compares every numeric value in the new results/results.json
   with results_published/results.json and reports PASS or the differences.
   The figures regenerate from the results; their image files may differ slightly
   from the published PNGs because of the plotting environment (fonts, renderer).

3. PVT bare-panel benchmark against Eicker & Dalibard (2011):
       python pvt_benchmark_eicker.py

Contents
  hybrid_model.py           hourly host (laundromat, car wash, commercial laundry), storage,
                            PVT night rejection and daytime PV and wash-water preheat,
                            hybrid cooler, water treatment and storage, and the
                            evaporative-tower and dry-cooler baseline models
  pvt_full_system_model.py  PVT surface energy balance (mechanism-resolved)
  run_all.py, make_rows.py, make_figures.py, reproduce_check.py   as above
  results_published/        results.json and rows.json used in the manuscript
  weather/                  seven TMY3 weather files (see below)
  pvt_rejection_model.py, pvt_mist_combined_model.py, pvt_benchmark_eicker.py
                            PVT sub-model development and benchmark scripts

Weather data
  Official NREL TMY3 station files for seven US airports:
    USA_AZ_Phoenix-Sky.Harbor.Intl.AP.722780_TMY3.epw
    USA_NV_Las.Vegas-McCarran.Intl.AP.723860_TMY3.epw
    USA_CA_Fresno.Air.Terminal.723890_TMY3.epw
    USA_CA_Los.Angeles.Intl.AP.722950_TMY3.epw
    USA_CA_San.Francisco.Intl.AP.724940_TMY3.epw
    USA_FL_Miami.Intl.AP.722020_TMY3.epw
    USA_IL_Chicago-OHare.Intl.AP.725300_TMY3.epw
  Six are the copies distributed in the EnergyPlus repository
  (github.com/NREL/EnergyPlus, folder "weather"). The Los Angeles Intl Airport file
  (WMO 722950) is the same TMY3 dataset as redistributed in a public research
  archive (github.com/LBNL-ETA/annex80-heat-wave-epw). TMY3 data were produced by
  NREL (Wilcox and Marion, 2008, NREL/TP-581-43156).

Licensing
  Code in this folder: MIT License (see LICENSE).
  Weather files: redistributed unchanged from the sources above, which remain
  subject to their providers' terms.
