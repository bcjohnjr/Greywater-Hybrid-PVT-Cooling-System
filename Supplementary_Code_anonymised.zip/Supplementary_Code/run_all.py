"""Run every scenario reported in the manuscript and write results/results.json."""
import os, sys, json
from dataclasses import replace
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import hybrid_model as hm

ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)  # package or working tree
WDIR = os.path.join(ROOT, "weather")
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

CASES = {
    "A": hm.Config(n_acc=32, n_panels=100, dry_kW_35=30.0),     # 58.0 kW rated edge module
    "B": hm.Config(n_acc=72, n_panels=200, dry_kW_35=40.0),     # 130.5 kW rated rack-scale module
}
KEYS = ["water_total_m3", "water_municipal_m3", "water_film_m3", "water_pad_m3", "water_steril_m3",
        "permeate_m3", "unmet_MWh", "unmet_h", "fan_MWh", "fan_h", "fan_night_h", "pad_h",
        "silent_share", "pvt_passive_MWh", "pvt_film_MWh", "dry_MWh", "adia_MWh", "resid_MWh",
        "useful_MWh", "cool_elec_MWh", "pump_MWh", "ro_MWh", "WUE_total_L_kWh",
        "WUE_municipal_L_kWh", "recycled_share", "IT_MWh", "captured_MWh", "shift_MWh",
        "steril_MWh", "n_flush", "unmet_max_kW", "unmet_max_frac_IT", "unmet_energy_frac_IT",
        "host_heat_MWh", "host_compat_MWh", "pvt_th_potential_MWh", "pvt_preheat_MWh",
        "host_heat_supplied_MWh", "fuel_saved_MWh", "fuel_saved_pvt_MWh", "co2_saved_t", "greywater_m3"]

W = {c: hm.load_epw(os.path.join(WDIR, f)) for c, (f, z) in hm.CLIMATES.items()}
R = {"cases": {k: dict(v.__dict__, it_rated_kW=v.it_rated_kW) for k, v in CASES.items()},
     "tower_config": hm.TowerConfig().__dict__.copy(), "climate": {}, "main": {}, "compare": {},
     "sens": {}, "monthly": {}, "daily": {}, "week": {}}
for c, (f, zone) in hm.CLIMATES.items():
    s = hm.climate_summary(W[c]); s["zone"] = zone; s["file"] = f
    R["climate"][c] = s


def pick(S):
    return {k: S[k] for k in KEYS}


def tower(w, cfg, Q):
    return hm.simulate_tower(w, Q, replace(hm.TowerConfig(), T_hot=cfg.T_hot))


for case, cfg in CASES.items():
    R["main"][case], R["compare"][case], R["monthly"][case], R["daily"][case] = {}, {}, {}, {}
    Qc = cfg.it_rated_kW * cfg.util * cfg.capture
    for c, w in W.items():
        S = hm.simulate(w, c, cfg, keep_hourly=True)
        H = S.pop("hourly")
        R["main"][case][c] = pick(S)
        mon = lambda k: [float(H[k][w["month"] == m].sum()) for m in range(1, 13)]
        R["monthly"][case][c] = {k: mon(k) for k in ["w_total", "w_film", "w_pad_evap", "w_pad_bleed",
                                                     "w_steril", "w_municipal", "permeate", "pvt_passive",
                                                     "pvt_film", "dry", "adia"]}
        day = np.arange(8760) // 24
        R["daily"][case][c] = {
            "water_L": [float(H["w_total"][day == d].sum() * 1000) for d in range(365)],
            "Tmax": [float(w["T"][day == d].max()) for d in range(365)],
            "Twb_max": [float(w["Twb"][day == d].max()) for d in range(365)],
            "Tnight": [float(np.mean(w["T"][(day == d) & w["night"]])) for d in range(365)],
        }
        if c == "Phoenix":
            d0 = int(np.argmax([sum(R["daily"][case][c]["Tmax"][i:i + 7]) for i in range(358)]))
            sl = slice(d0 * 24, d0 * 24 + 168)
            R["week"][case] = {"start_day": d0, **{k: H[k][sl].tolist() for k in
                               ["resid", "pvt_passive", "pvt_film", "dry", "adia", "unmet", "w_total", "store"]},
                               "T": w["T"][sl].tolist(), "Twb": w["Twb"][sl].tolist(),
                               "night": w["night"][sl].astype(int).tolist()}
        tf = tower(w, cfg, np.full(8760, Qc))
        tr = tower(w, cfg, H["resid"])
        R["compare"][case][c] = {
            "tower_full": tf, "tower_resid": tr,
            "proposed_municipal": pick(hm.simulate(w, c, replace(cfg, recycle_on=False))),
            "hybrid_noPVT_municipal": pick(hm.simulate(w, c, replace(cfg, pvt_on=False, recycle_on=False))),
            "hybrid_noPVT_recycled": pick(hm.simulate(w, c, replace(cfg, pvt_on=False))),
            "dry_only_noPVT": pick(hm.simulate(w, c, replace(cfg, pvt_on=False, adiabatic_on=False, recycle_on=False))),
            "night_fan_first": pick(hm.simulate(w, c, replace(cfg, night_order="fan"))),
            "night_shift": pick(hm.simulate(w, c, replace(cfg, night_shift=True))),
            "it_kWh": S["IT_MWh"] * 1000,
        }
        print(case, c, flush=True)

SENS = {
    "A": {"dry_kW_35": [10.0, 20.0, 30.0, 45.0], "util": [0.60, 0.80, 0.95], "f_T": [0.25, 0.60, 1.00],
          "T_panel": [35.0, 40.0, 45.0], "T_hot": [40.0, 45.0, 50.0], "n_panels": [50, 100, 150],
          "host": ["laundromat", "carwash"], "pvt_derate": [0.74, 1.0]},
    "B": {"n_panels": [100, 150, 200, 300], "dry_kW_35": [20.0, 40.0, 70.0, 100.0],
          "util": [0.60, 0.80, 0.95], "f_T": [0.25, 0.60, 1.00], "T_panel": [35.0, 40.0, 45.0],
          "T_hot": [40.0, 45.0, 50.0], "host": ["laundromat", "carwash"],
          "grey_L_per_load": [15.0, 30.0, 60.0], "ro_recovery": [0.50, 0.60, 0.75],
          "tank_m3": [0.5, 2.0, 5.0], "pad_eff": [0.70, 0.85, 0.95], "pvt_derate": [0.74, 1.0]},
}
for case, sens in SENS.items():
    R["sens"][case] = {}
    for p, vals in sens.items():
        R["sens"][case][p] = {}
        for v in vals:
            cfg = replace(CASES[case], **{p: v})
            Qc = cfg.it_rated_kW * cfg.util * cfg.capture
            R["sens"][case][p][str(v)] = {}
            for c, w in W.items():
                d = pick(hm.simulate(w, c, cfg))
                tf = tower(w, cfg, np.full(8760, Qc))
                d["tower_water_m3"], d["tower_elec_MWh"] = tf["water_m3"], tf["elec_MWh"]
                if case == "B" and p == "n_panels":
                    nf = hm.simulate(w, c, replace(cfg, night_order="fan"))
                    d["fanfirst_water_m3"], d["fanfirst_fan_night_h"] = nf["water_total_m3"], nf["fan_night_h"]
                R["sens"][case][p][str(v)][c] = d
        print("sens", case, p, flush=True)

# PVT capacity uncertainty: derating and mechanism ablation, both cases, all climates
PVT_UNC = {
    "full_x1.00": dict(), "full_x0.74": dict(pvt_derate=0.74), "full_x0.50": dict(pvt_derate=0.50),
    "no_stack": dict(pvt_mech="no_stack"), "no_shroud": dict(pvt_mech="no_shroud"),
    "no_emitter": dict(pvt_mech="no_emitter"), "no_thermo": dict(pvt_mech="no_thermo"),
    "bare_x0.74": dict(pvt_mech="bare", pvt_derate=0.74),
    "bare_x0.50": dict(pvt_mech="bare", pvt_derate=0.50),
}
R["pvt_unc"] = {}
for case, cfg0 in CASES.items():
    R["pvt_unc"][case] = {}
    for lab, kw in PVT_UNC.items():
        cfg = replace(cfg0, **kw)
        Qc = cfg.it_rated_kW * cfg.util * cfg.capture
        R["pvt_unc"][case][lab] = {}
        for c, w in W.items():
            d = pick(hm.simulate(w, c, cfg))
            tf = tower(w, cfg, np.full(8760, Qc))
            d["tower_water_m3"], d["tower_elec_MWh"] = tf["water_m3"], tf["elec_MWh"]
            R["pvt_unc"][case][lab][c] = d
        print("pvt_unc", case, lab, flush=True)

# Conventional dry-cooler comparison: equal duty (same residual heat), footprint, and electricity
# with the PVT array's daytime PV output credited, both directly and on a same-roof basis
R["dry"] = {}
for case, cfg in CASES.items():
    R["dry"][case] = {}
    coil_inst = cfg.dry_kW_35 / 10.0 * hm.DRY_M2_PER_UA * hm.DRY_INSTALL_FACTOR
    for c, w in W.items():
        S = hm.simulate(w, c, cfg, keep_hourly=True); H = S.pop("hourly")
        A_pvt = S["A_pvt_m2"]; roof = A_pvt + coil_inst
        pv_kWh_m2 = hm.pv_hourly(w, 1.0)[0].sum()
        out = {"prop_rej_elec_MWh": S["cool_elec_MWh"] - cfg.pump_kW_per_kW * S["useful_MWh"],
               "prop_water_m3": S["water_total_m3"], "prop_fan_night_h": S["fan_night_h"],
               "prop_unmet_MWh": S["unmet_MWh"], "prop_coil_installed_m2": coil_inst,
               "A_pvt_m2": A_pvt, "roof_m2": roof, "pv_kWh_per_m2": pv_kWh_m2,
               "pvt_pv_MWh": pv_kWh_m2 * A_pvt / 1000}
        for lab, kw in {"design": dict(sizing="design"), "reliability": dict(sizing="reliability"),
                        "design_fan053": dict(sizing="design", fan_kW_per_kW=0.053)}.items():
            d = hm.dry_cooler_baseline(w, H["resid"], T_hot=cfg.T_hot, **kw)
            d["roof_pv_MWh"] = pv_kWh_m2 * max(roof - d["area_installed_m2"], 0.0) / 1000
            out["dry_" + lab] = d
        # proposed with the datasheet fan coefficient, for the matching sensitivity
        Sf = hm.simulate(w, c, replace(cfg, fan_kW_per_kW=0.053))
        out["prop_fan053_rej_elec_MWh"] = Sf["cool_elec_MWh"] - cfg.pump_kW_per_kW * Sf["useful_MWh"]
        # both systems with a 50 C loop
        S5 = hm.simulate(w, c, replace(cfg, T_hot=50.0), keep_hourly=True); H5 = S5.pop("hourly")
        out["prop_T50_rej_elec_MWh"] = S5["cool_elec_MWh"] - cfg.pump_kW_per_kW * S5["useful_MWh"]
        d5 = hm.dry_cooler_baseline(w, H5["resid"], T_hot=50.0, sizing="design")
        d5["roof_pv_MWh"] = pv_kWh_m2 * max(roof - d5["area_installed_m2"], 0.0) / 1000
        out["dry_design_T50"] = d5
        R["dry"][case][c] = out
    print("dry", case, flush=True)

# Three host types: retail laundromat (central), car wash, commercial laundry.
# Each with the tower (equal duty) and the dry cooler (design sizing, equal duty) and PV accounting.
R["hosts"] = {}
for case, cfg0 in CASES.items():
    R["hosts"][case] = {}
    for host in ["laundromat", "carwash", "commercial_laundry"]:
        cfg = replace(cfg0, host=host)
        coil_inst = cfg.dry_kW_35 / 10.0 * hm.DRY_M2_PER_UA * hm.DRY_INSTALL_FACTOR
        R["hosts"][case][host] = {}
        for c, w in W.items():
            S = hm.simulate(w, c, cfg, keep_hourly=True); H = S.pop("hourly")
            d = pick(S)
            d["rej_elec_MWh"] = S["cool_elec_MWh"] - cfg.pump_kW_per_kW * S["useful_MWh"]
            tr = tower(w, cfg, H["resid"])
            d["tower_resid_water_m3"], d["tower_resid_elec_MWh"] = tr["water_m3"], tr["elec_MWh"]
            dd = hm.dry_cooler_baseline(w, H["resid"], T_hot=cfg.T_hot, sizing="design")
            pv_m2 = hm.pv_hourly(w, 1.0)[0].sum()
            roof = S["A_pvt_m2"] + coil_inst
            d["dry_elec_MWh"], d["dry_area_installed_m2"] = dd["elec_MWh"], dd["area_installed_m2"]
            d["dry_fan_night_h"], d["dry_unmet_MWh"] = dd["fan_night_h"], dd["unmet_MWh"]
            d["pvt_pv_MWh"] = pv_m2 * S["A_pvt_m2"] / 1000
            d["dry_roof_pv_MWh"] = pv_m2 * max(roof - dd["area_installed_m2"], 0.0) / 1000
            R["hosts"][case][host][c] = d
        print("hosts", case, host, flush=True)

# tower-baseline assumption sensitivity (Case A and B, central proposed)
R["tower_sens"] = {}
for case, cfg in CASES.items():
    Qc = cfg.it_rated_kW * cfg.util * cfg.capture
    R["tower_sens"][case] = {}
    for lab, kw in {"coc2": dict(coc=2.0), "coc3": dict(coc=3.0), "coc6": dict(coc=6.0),
                    "fan004": dict(fan_kW_per_kW=0.004), "fan016": dict(fan_kW_per_kW=0.016)}.items():
        R["tower_sens"][case][lab] = {c: hm.simulate_tower(w, np.full(8760, Qc), replace(hm.TowerConfig(), **kw))
                                      for c, w in W.items()}

with open(os.path.join(OUT, "results.json"), "w") as f:
    json.dump(R, f, indent=1, default=float)
print("written")
