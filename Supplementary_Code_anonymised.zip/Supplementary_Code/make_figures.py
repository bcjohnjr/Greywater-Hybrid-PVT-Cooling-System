"""Generate manuscript figures from results/results.json."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)  # package or working tree
R = json.load(open(os.path.join(ROOT, "results", "results.json")))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)
CL = list(R["climate"].keys())
CCOL = {"Phoenix": "#c0392b", "Las Vegas": "#e67e22", "Fresno": "#d4ac0d",
        "San Francisco": "#2e86c1", "Miami": "#16a085", "Chicago": "#5b2c6f",
        "Los Angeles": "#8e44ad"}
MCOL = {"pvt_passive": "#1f4e79", "pvt_film": "#5dade2", "dry": "#909497", "adia": "#e59866", "unmet": "#c0392b"}
MLAB = {"pvt_passive": "PVT passive (night, fanless)", "pvt_film": "PVT evaporative film (night)",
        "dry": "Hybrid cooler, dry", "adia": "Hybrid cooler, adiabatic", "unmet": "Unmet (power cap)"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150})


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


# ---- Fig 1 schematic --------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.4, 4.6))
ax.set_xlim(0, 100); ax.set_ylim(-8, 64); ax.axis("off")
def box(x, y, w, h, t, fc, fs=7.2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.5", fc=fc, ec="#2c3e50", lw=0.8))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs, linespacing=1.25)
def arr(x1, y1, x2, y2, c="#2c3e50", ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9, color=c, lw=1.0, ls=ls,
                                 shrinkA=0, shrinkB=0))
def lab(x, y, t, c="#2c3e50", ha="center"):
    ax.text(x, y, t, fontsize=6.4, color=c, ha=ha, va="center",
            bbox=dict(fc="white", ec="none", pad=0.6))
box(1, 42, 17, 12, "Liquid-cooled\nGPU module\n(85% captured)", "#d6eaf8")
box(27, 42, 18, 12, "Host process heat\n(hot-water tank,\ndryers / bays)", "#fdebd0")
box(27, 22, 18, 10, "Thermal store\n110 kWh", "#fdebd0")
box(57, 40, 21, 18, "PVT array\n(170 or 340 m²)\nnight: passive, then\nevaporative film\nday: electricity and\nwash-water preheat", "#d4efdf", fs=6.6)
box(57, 21, 21, 15, "Hybrid cooler\ndry coil, then\nadiabatic pads\n(day and overflow;\nweekly 70 °C flush)", "#eaecee")
box(1, 2, 17, 11, "Host greywater\n(laundry or\nwash drain)", "#e8daef")
box(27, 2, 18, 11, "Pretreatment,\nreverse osmosis\nand UV", "#e8daef")
box(57, 2, 21, 11, "Unheated buffer\ntank (2 m³)", "#e8daef")
box(85, 2, 14, 11, "Municipal\ntop-up (only if\ntank empty)", "#fadbd8", fs=6.6)
# heat
arr(18.5, 48, 26.5, 48); lab(22.5, 51.5, "heat")
arr(36, 41.5, 36, 32.5); lab(40.5, 37, "surplus")
arr(45.5, 47, 56.5, 47); lab(51, 45, "residual")
arr(56.5, 53, 45.5, 53, "#d35400", ls="--"); lab(50.5, 55.5, "day: preheat", "#d35400")
arr(45.5, 45, 56.5, 31); lab(47.8, 34.5, "residual")
# water
arr(18.5, 7.5, 26.5, 7.5, "#7d3c98"); arr(45.5, 7.5, 56.5, 7.5, "#7d3c98"); lab(51, 10.5, "permeate", "#7d3c98")
arr(36, 1.5, 36, -5, "#7d3c98"); lab(36, -6.5, "RO concentrate to sewer", "#7d3c98")
arr(64, 13.5, 64, 20.5, "#7d3c98"); lab(64, 17, "pad water", "#7d3c98")
ax.plot([78.5, 81.5, 81.5], [11, 11, 49], color="#7d3c98", lw=1.0, ls="--")
arr(81.5, 49, 78.5, 49, "#7d3c98"); lab(81.5, 40, "film\nwater", "#7d3c98")
arr(84.5, 5, 78.5, 5, "#c0392b", ls="--")
ax.text(50, 62, "Night: PVT passive → PVT film → dry coil → adiabatic pads      Day: dry coil → adiabatic pads",
        ha="center", fontsize=7.4, style="italic")
save(fig, "Fig1_system")

# ---- Fig 2 annual rejection by mechanism -----------------------------------
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.2), sharey=True)
for ax, case in zip(axs, "AB"):
    left = np.zeros(len(CL))
    for k in ["pvt_passive", "pvt_film", "dry", "adia", "unmet"]:
        v = np.array([R["main"][case][c][k + "_MWh"] for c in CL])
        ax.barh(CL, v, left=left, color=MCOL[k], label=MLAB[k], height=0.65)
        left += v
    ax.set_title(f"Case {case}: {R['cases'][case]['it_rated_kW']:.1f} kW rated IT", fontsize=9)
    ax.set_xlabel("Heat rejected (MWh yr$^{-1}$)")
    ax.invert_yaxis() if case == "A" else None
axs[0].legend(loc="upper center", bbox_to_anchor=(1.05, -0.22), ncol=3, fontsize=7, frameon=False)
save(fig, "Fig2_rejection_by_mechanism")

# ---- Fig 3 monthly water Case B ----------------------------------------------
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0))
mo = np.arange(1, 13)
for c in CL:
    m = R["monthly"]["B"][c]
    axs[0].plot(mo, np.array(m["w_total"]) * 1000 / 1000, "-o", ms=3, color=CCOL[c], label=c)
axs[0].set_xticks(mo); axs[0].set_xticklabels("JFMAMJJASOND"); axs[0].set_ylabel("Cooling water (m$^3$ month$^{-1}$)")
axs[0].set_title("(a) Monthly water, Case B", fontsize=9)
axs[0].legend(fontsize=6.5, frameon=False)
# use breakdown for Phoenix
m = R["monthly"]["B"]["Phoenix"]
b = np.zeros(12)
for k, lab, col in [("w_film", "PVT film", MCOL["pvt_film"]), ("w_pad_evap", "Pad evaporation", MCOL["adia"]),
                    ("w_pad_bleed", "Pad bleed", "#a04000"), ("w_steril", "Thermal sterilisation flush", "#7d3c98")]:
    v = np.array(m[k]); axs[1].bar(mo, v, bottom=b, color=col, label=lab); b += v
axs[1].set_xticks(mo); axs[1].set_xticklabels("JFMAMJJASOND"); axs[1].set_ylabel("m$^3$ month$^{-1}$")
axs[1].set_title("(b) Phoenix, by end use (all recycled)", fontsize=9); axs[1].legend(fontsize=6.5, frameon=False, loc="upper left")
save(fig, "Fig3_monthly_water")

# ---- Fig 4 daily water vs weather -------------------------------------------
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0), sharey=True)
for c in CL:
    d = R["daily"]["B"][c]
    axs[0].scatter(d["Tmax"], d["water_L"], s=5, alpha=0.6, color=CCOL[c], label=c)
    axs[1].scatter(d["Twb_max"], d["water_L"], s=5, alpha=0.6, color=CCOL[c])
axs[0].set_xlabel("Daily maximum dry-bulb (°C)"); axs[1].set_xlabel("Daily maximum wet-bulb (°C)")
axs[0].set_ylabel("Daily cooling water (L d$^{-1}$)")
axs[0].legend(fontsize=6.5, frameon=False, markerscale=2)
axs[0].set_title("(a)", fontsize=9, loc="left"); axs[1].set_title("(b)", fontsize=9, loc="left")
save(fig, "Fig4_daily_water_weather")

# ---- Fig 5 Phoenix hottest week dispatch -------------------------------------
wk = R["week"]["B"]; t = np.arange(168) / 24.0
fig, axs = plt.subplots(2, 1, figsize=(7.4, 4.2), sharex=True, gridspec_kw={"height_ratios": [2.2, 1]})
stack = [np.array(wk[k]) for k in ["pvt_passive", "pvt_film", "dry", "adia", "unmet"]]
axs[0].stackplot(t, *stack, colors=[MCOL[k] for k in MCOL], labels=[MLAB[k] for k in MCOL], lw=0)
ax2 = axs[0].twinx(); ax2.plot(t, wk["T"], color="k", lw=0.8, label="Dry-bulb"); ax2.plot(t, wk["Twb"], color="k", lw=0.8, ls=":", label="Wet-bulb")
ax2.set_ylabel("°C"); ax2.spines["top"].set_visible(False)
axs[0].set_ylabel("Heat rejected (kW)"); axs[0].set_ylim(0, 100)
h1, l1 = axs[0].get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
axs[0].legend(h1 + h2, l1 + l2, fontsize=6.5, ncol=4, loc="lower center", bbox_to_anchor=(0.5, 1.0), frameon=False)
for i in range(168):
    if wk["night"][i]:
        axs[1].axvspan(t[i], t[i] + 1 / 24, color="#d6eaf8", lw=0)
axs[1].bar(t, np.array(wk["w_total"]) * 1000, width=1 / 24, color=MCOL["adia"], align="edge")
axs[1].set_ylabel("Water (L h$^{-1}$)"); axs[1].set_xlabel(f"Day of hottest week (starts day {wk['start_day'] + 1})")
save(fig, "Fig5_phoenix_week")

# ---- Fig 6 comparison with evaporative tower ---------------------------------
fig, axs = plt.subplots(2, 2, figsize=(7.4, 4.8))
x = np.arange(len(CL)); wdt = 0.38
for j, case in enumerate("AB"):
    it = np.array([R["compare"][case][c]["it_kWh"] for c in CL])
    tw = np.array([R["compare"][case][c]["tower_full"]["water_m3"] for c in CL]) * 1000 / it
    pw = np.array([R["main"][case][c]["water_total_m3"] for c in CL]) * 1000 / it
    te = np.array([R["compare"][case][c]["tower_full"]["elec_MWh"] for c in CL]) * 1000 / it
    pe = np.array([R["main"][case][c]["cool_elec_MWh"] for c in CL]) * 1000 / it
    axs[0, j].bar(x - wdt / 2, tw, wdt, color="#7f8c8d", label="Evaporative cooling tower")
    axs[0, j].bar(x + wdt / 2, pw, wdt, color="#1f4e79", label="PVT + recycled-water hybrid")
    axs[1, j].bar(x - wdt / 2, te * 1000, wdt, color="#7f8c8d")
    axs[1, j].bar(x + wdt / 2, pe * 1000, wdt, color="#1f4e79")
    for i in range(len(CL)):
        axs[0, j].text(x[i] + wdt / 2, pw[i] + 0.03, f"{(pw[i] / tw[i] - 1) * 100:.0f}%", ha="center", fontsize=6)
        axs[1, j].text(x[i] + wdt / 2, pe[i] * 1000 + 0.3, f"{(pe[i] / te[i] - 1) * 100:.0f}%", ha="center", fontsize=6)
    axs[0, j].set_title(f"Case {case}", fontsize=9)
    for a in axs[:, j]:
        a.set_xticks(x); a.set_xticklabels([c.replace(" ", "\n") for c in CL], fontsize=6.5)
axs[0, 0].set_ylabel("Water (L kWh$_{IT}^{-1}$)"); axs[1, 0].set_ylabel("Cooling electricity\n(Wh kWh$_{IT}^{-1}$)")
axs[0, 0].legend(fontsize=6.5, frameon=False)
save(fig, "Fig6_vs_tower")

# ---- Fig 7 array-size trade-off, Case B --------------------------------------
S = R["sens"]["B"]["n_panels"]; npn = [int(k) for k in S]
area = [n * 1.7 for n in npn]
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0))
for c in ["Phoenix", "Las Vegas", "Fresno", "Miami"]:
    axs[0].plot(area, [S[k][c]["water_total_m3"] for k in S], "-o", ms=3, color=CCOL[c], label=f"{c}, PVT film before fans")
    axs[0].plot(area, [S[k][c]["fanfirst_water_m3"] for k in S], "--s", ms=3, color=CCOL[c], label=f"{c}, fans before PVT film")
    axs[1].plot(area, [S[k][c]["fan_night_h"] for k in S], "-o", ms=3, color=CCOL[c])
    axs[1].plot(area, [S[k][c]["fanfirst_fan_night_h"] for k in S], "--s", ms=3, color=CCOL[c])
axs[0].set_xlabel("PVT array area (m²)"); axs[0].set_ylabel("Cooling water (m$^3$ yr$^{-1}$)")
axs[1].set_xlabel("PVT array area (m²)"); axs[1].set_ylabel("Night hours with cooler fans running")
axs[0].legend(fontsize=5.6, frameon=False, ncol=1)
axs[0].set_title("(a)", fontsize=9, loc="left"); axs[1].set_title("(b)", fontsize=9, loc="left")
fig.subplots_adjust(wspace=0.38)
save(fig, "Fig7_array_tradeoff")

# ---- Fig 8 dry-coil size, Case B ---------------------------------------------
S = R["sens"]["B"]["dry_kW_35"]; dk = [float(k) for k in S]
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0))
for c in CL:
    axs[0].plot(dk, [S[k][c]["water_total_m3"] for k in S], "-o", ms=3, color=CCOL[c], label=c)
    axs[1].plot(dk, [S[k][c]["unmet_MWh"] for k in S], "-o", ms=3, color=CCOL[c])
axs[0].set_xlabel("Dry-coil capacity at 35 °C air (kW)"); axs[0].set_ylabel("Cooling water (m$^3$ yr$^{-1}$)")
axs[1].set_xlabel("Dry-coil capacity at 35 °C air (kW)"); axs[1].set_ylabel("Unmet heat (MWh yr$^{-1}$)")
axs[0].legend(fontsize=6.5, frameon=False)
axs[0].set_title("(a)", fontsize=9, loc="left"); axs[1].set_title("(b)", fontsize=9, loc="left")
save(fig, "Fig8_drycoil_size")
print("figures done")
